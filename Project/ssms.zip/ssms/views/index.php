<?php
header("Location: ./..");	
exit();
?>