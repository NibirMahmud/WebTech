<?php
// require './../model/login.php';

function getFirstName()
{
	return getUserFirtName();
}