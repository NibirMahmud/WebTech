<?php 

require_once 'db_connect.php';

function checkLogin($data){
    $conn = db_conn();
    $selectQuery = "SELECT * FROM `users` where username = ? and password = ?";

    try {
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([
            $data['username'],
            $data['password']
        ]);
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($stmt-> rowCount() >0) {
        return true;
    }
    else
    {
        return false;
    }
}

/*function showAllStudents(){
    $conn = db_conn();
    $selectQuery = 'SELECT * FROM `user_info` ';
    try{
        $stmt = $conn->query($selectQuery);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $rows;
}
*/
function showUser($id){
    $conn = db_conn();
    $selectQuery = "SELECT * FROM `userdetails` where username = ?";

    try {
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([$id]);
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row;
}


// function addStudent($data){
//     $conn = db_conn();
//     $selectQuery = "INSERT into user_info (Name, Surname, Username, Password, image)
// VALUES (:name, :surname, :username, :password, :image)";
//     try{
//         $stmt = $conn->prepare($selectQuery);
//         $stmt->execute([
//             ':name' => $data['name'],
//             ':surname' => $data['surname'],
//             ':username' => $data['username'],
//             ':password' => $data['password'],
//             ':image' => $data['image']
//         ]);
//     }catch(PDOException $e){
//         echo $e->getMessage();
//     }
    
//     $conn = null;
//     return true;
// }


function updateUser($id, $data){
    $conn = db_conn();
    $selectQuery = "UPDATE userdetails set firstname = ?, lastname = ?, varsityid = ? where username = ?;";
    try{
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([
            $data['firstname'], $data['lastname'], $data['varsityid'], $id
        ]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    
    $conn = null;
    return true;
}
function updatePass($id, $data){
    $conn = db_conn();
    $selectQuery = "UPDATE users set password = ? where username = ?;";
    try{
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([
            $data['newpass'], $id
        ]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    
    $conn = null;
    return true;
}

// function deleteStudent($id){
//     $conn = db_conn();
//     $selectQuery = "DELETE FROM `user_info` WHERE `ID` = ?";
//     try{
//         $stmt = $conn->prepare($selectQuery);
//         $stmt->execute([$id]);
//     }catch(PDOException $e){
//         echo $e->getMessage();
//     }
//     $conn = null;

//     return true;
// }