<?php
session_start();
if (empty($_SESSION['username'])) {
	header('Location: login.php');
}
require_once './controller/userInfo.php';
$data=fetchUser($_SESSION['username']);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Profile|View</title>
	<style type="text/css">
		fieldset {
		  background-color: #eeeeee;
		  width: 50%;
		}

		legend {
		  background-color: gray;
		  color: white;
		  padding: 5px 10px;
		}
	</style>
</head>
<body style="padding-top: 150px;">
	<center>
		<!-- <br><br><br><br><br> -->
		<table width="50%" border="1" style="background-color: #F5D57D; height: 300px; text-align: center;">
			<tr>
				<td width="40%"><a href="dashboard.php" style="text-decoration: none; color: #000000;">Dashboard</a></td>
				<td rowspan="5">
					<form action="./controller/updateUser.php" method="POST">
						<h3>Edit Profile</h3>
						<p><b>First Name</b> &nbsp;&nbsp;<input type="text" name="firstname" value="<?php echo $data['firstname'] ?>"></p>
						<p><b>Last Name</b> &nbsp;&nbsp;<input type="text" name="lastname" value="<?php echo $data['lastname'] ?>"></p>
						<p><b>Varsity Id</b> &nbsp;&nbsp;<input type="text" name="varsityid" value="<?php echo $data['varsityid'] ?>"></p>
						<p><input type="submit" name="edit" value="Edit"></p>
					</form>
				</td>
			</tr>
			<tr>
				<td><a href="viewProfile.php" style="text-decoration: none; color: #000000;">View Profile</a></td>
			</tr>
			<tr>
				<td><a href="#" style="text-decoration: none;color: #000000;">Edit Profile</a></td>
			</tr>
			<tr>
				<td><a href="./changepass.php" style="text-decoration: none;color: #000000;">Change Password</a></td>
			</tr>
			<tr>
				<td><a href="./logout.php" style="text-decoration: none;color: #000000;">Logout</a></td>
			</tr>
		</table>
	</center>
</body>
</html>