<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
</head>
<body style="padding-top: 150px;">
	<center>
		<!-- <br><br><br><br><br> -->
		<table width="50%" border="1" style="background-color: #F5D57D; height: 300px; text-align: center;">
			<tr>
				<td rowspan="3" width="40%"><img width="70px" height="90px" src="14519.png"><h3>Public User</h3></td>
				<td><a href="#" style="text-decoration: none;color: #000000;">Public Home</a></td>
			</tr>
			<tr>
				<td><a href="registration.php" style="text-decoration: none; color: #000000;">Registration</a></td>
			</tr>
			<tr>
				<td><a href="./login.php" style="text-decoration: none;color: #000000;">Login</a></td>
			</tr>
		</table>
	</center>
</body>
</html>