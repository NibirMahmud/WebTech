<?php 

require_once 'model.php';

/*function fetchAllStudents(){
	return showAllStudents();

}*/
function fetchUser($id){
	return showUser($id);

}
