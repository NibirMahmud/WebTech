<?php
session_start();
if (isset($_SESSION['username'])) {
	header('Location: ./dashboard.php');
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
	<style type="text/css">
		fieldset {
		  background-color: #eeeeee;
		  width: 50%;
		}

		legend {
		  background-color: gray;
		  color: white;
		  padding: 5px 10px;
		}
	</style>
</head>
<body>
	<center>
		<br><br><h1><u>Login</u></h1><br><br>
		<form action="controller/loginController.php" method="POST" enctype="multipart/form-data">
			<fieldset>
				<legend>Login</legend><br>
				<label for="username"> Username &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </label>
				<input type="text" id="username" name="username"><br><br>
				<label for="password"> Password &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
				<input type="password" id="password" name="password"><br><br>
				<input type="submit" name = "login" value="Login" style="font-size: 110%;"><br><br> 
			</fieldset>
			
		</form>
	</center>
</body>
</html>