<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
	<style type="text/css">
		a{
			text-decoration: none;
			font-size: 130%;
		}
	</style>
</head>
<body>
	<br><br><br><br><br>
	<center>
		<h1><u>Demo Database Connection</u></h1><br><br><br><br>
		<h2>Choose your option</h2>
		<button ><a href="./addProduct.php">Add Product</a></button>&nbsp;&nbsp;&nbsp;
		<button ><a href="./showAllProducts.php">Show All Product</a></button>
	</center>
	<!-- <a href="./addProduct.php">Add Product</a>
	<a href="./showAllProducts.php">Show All Product</a> -->
</body>
</html>

